
 
 
   const portfolio = [

{
    id:"01",
    title:"Pizza Mobile App",
    img: "../../../public/Images/m12.jpg",
    category: "Mobile App",
    keyword:["Mobile", "App", "Mobile UI-UX"]
},
{
    id:"02",
    title:"Pizza Mobile App",
    img: "../../../public/Images/m12.jpg",
    category: "Web Design",
    keyword:["Mobile", "App", "Mobile UI-UX"]
},
{
    id:"03",
    title:"Pizza Mobile App",
    img: "../../../public/Images/m13.jpg",
    category: "Mobile App",
    keyword:["Mobile", "App", "Mobile UI-UX"]
},
{
    id:"04",
    title:"Fashion Shooping App",
    img: "../../../public/Images/m14.jpg",
    category: "Mobile App",
    keyword:["Mobile", "App", "Mobile UI-UX"]
},
{
    id:"05",
    title:"Transpotation Mobile App",
    img: "../../../public/Images/m12.jpg",
    category: "Web Design",
    keyword:["Mobile", "App", "Mobile UI-UX"]
},
{
    id:"06",
    title:"Workout Tracker App",
    img: "../../../public/Images/m11.jpg",
    category: "Web Design",
    keyword:["Mobile", "App", "Mobile UI-UX"]
},


]






export default portfolio