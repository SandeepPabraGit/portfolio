import React, { Fragment } from 'react'
import Skill from './components/UI/Skill'

function skill() {
  return <Fragment>
<Skill/>

  </Fragment>
}

export default skill
